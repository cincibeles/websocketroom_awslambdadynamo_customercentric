import { ApiGatewayManagementApiClient, PostToConnectionCommand } from "@aws-sdk/client-apigatewaymanagementapi";

export const handler = async (event) => {
  const connectionId = event.requestContext.connectionId;
  const routeKey = event.requestContext.routeKey;
  const domainName = event.requestContext.domainName;
  const stage = event.requestContext.stage;

  // Configure API Gateway Management API Client
  const apigwManagementApi = new ApiGatewayManagementApiClient({
    endpoint: `https://${domainName}/${stage}`,
  });

  try {
    switch (routeKey) {
      case "$connect":
        // Connection handled successfully
        break;

      case "$disconnect":
        // Disconnection handled successfully
        break;

      case "get_id":
        // Client requests its own connection ID
        await apigwManagementApi.send(new PostToConnectionCommand({
          ConnectionId: connectionId,
          Data: new TextEncoder().encode(JSON.stringify({
            type: "your_id",
            id: connectionId
          }))
        }));
        break;

      case "route":
        // Client wants to route a message to other connection(s)
        const body = JSON.parse(event.body);
        const { targets, payload } = body;
        
        if (!targets || !payload) {
          return { statusCode: 400, body: 'Missing targets or payload' };
        }

        const targetArray = Array.isArray(targets) ? targets : [targets];
        
        // Send the payload to all specified targets
        const postPromises = targetArray.map(async (targetId) => {
          try {
            await apigwManagementApi.send(new PostToConnectionCommand({
              ConnectionId: targetId,
              Data: new TextEncoder().encode(JSON.stringify(payload))
            }));
          } catch (e) {
            if (e.name === 'GoneException') {
              console.log(`Connection ${targetId} is gone.`);
            } else {
              console.error(`Error sending to ${targetId}:`, e);
            }
          }
        });

        await Promise.all(postPromises);
        break;

      default:
        console.warn(`Unsupported route: "${routeKey}"`);
        return { statusCode: 400, body: `Unsupported route: "${routeKey}"` };
    }
  } catch (err) {
    console.error(err);
    return { statusCode: 500, body: 'Failed to process request: ' + err.message };
  }

  return { statusCode: 200, body: 'OK' };
};
